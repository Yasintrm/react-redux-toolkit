import React from "react";
import { DeviceTable } from "../features/device/DeviceTable";

export const OverviewContainer = () => {

  return (
    <>
      <DeviceTable />
    </>
  );
};